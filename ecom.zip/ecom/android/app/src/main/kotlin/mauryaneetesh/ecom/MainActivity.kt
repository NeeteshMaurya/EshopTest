package mauryaneetesh.ecom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
